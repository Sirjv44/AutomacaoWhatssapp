#!/usr/bin/env python3
"""
Script para iniciar a aplicação completa WhatsApp Automation
Frontend (buildado) + Backend (Flask + Playwright)
"""

import subprocess
import sys
import os
import time
import threading
import webbrowser
import platform

def install_backend_dependencies():
    """Instala as dependências do backend"""
    print("📦 Instalando dependências do backend...")
    try:
        result = subprocess.run([
            sys.executable, "-m", "pip", "install", "-r", "requirements.txt"
        ], cwd="backend", capture_output=True, text=True)
        
        if result.returncode == 0:
            print("Dependências do backend instaladas com sucesso")
            print("Instalando navegadores do Playwright...")
            result_playwright = subprocess.run([
                sys.executable, "-m", "playwright", "install", "chromium"
            ], cwd="backend", capture_output=True, text=True)

            if result_playwright.returncode == 0:
                print(" Navegadores do Playwright instalados com sucesso")
            else:
                print(f" Aviso na instalação dos navegadores: {result_playwright.stderr}")
        else:
            print(f" Aviso na instalação das dependências: {result.stderr}")
    except Exception as e:
        print(f" Erro ao instalar dependências do backend: {e}")

def start_backend():
    """Inicia o servidor backend (Flask)"""
    print(" Iniciando backend Flask...")
    subprocess.Popen(["python", "app.py"], cwd="backend", shell=True)

def open_browser():
    """Abre o navegador apontando para a interface"""
    time.sleep(5)  # Tempo para garantir que o backend iniciou
    print("🌐 Abrindo navegador em http://localhost:5000")
    webbrowser.open("http://localhost:5000")

def main():
    print(" WhatsApp Automation Suite")
    print("=" * 60)
    print("Backend Python (Flask API)")
    print("Frontend React (buildado)")
    print("=" * 60)

    if not os.path.exists("backend/app.py"):
        print(" Backend não encontrado em backend/app.py")
        return
    
    dist_path = os.path.join(os.getcwd(), "dist")
    index_path = os.path.join(dist_path, "index.html")
    assets_path = os.path.join(dist_path, "assets")

    if not os.path.exists(index_path) or not os.path.exists(assets_path):
        print("❌ Frontend buildado não encontrado em /dist (index.html ou pasta assets ausente)")
        return


    try:
        install_backend_dependencies()

        backend_thread = threading.Thread(target=start_backend, daemon=True)
        backend_thread.start()

        open_browser()

        # Mantém o processo principal ativo
        while True:
            time.sleep(1)

    except KeyboardInterrupt:
        print("\n⏹ Aplicação interrompida pelo usuário")
    except Exception as e:
        print(f" Erro geral: {e}")

if __name__ == "__main__":
    main()
